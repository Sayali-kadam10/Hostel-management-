
package p1;
import javax.persistence.*;
@Entity
public class NewStudent {
    @Id
    private int s_id;
    @Column
    private String s_mobile,s_name,sf_name,sl_name,s_email,s_address,sc_name,sa_number;

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getS_mobile() {
        return s_mobile;
    }

    public void setS_mobile(String s_mobile) {
        this.s_mobile = s_mobile;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getSf_name() {
        return sf_name;
    }

    public void setSf_name(String sf_name) {
        this.sf_name = sf_name;
    }

    public String getSl_name() {
        return sl_name;
    }

    public void setSl_name(String sm_name) {
        this.sl_name = sm_name;
    }

    public String getS_email() {
        return s_email;
    }

    public void setS_email(String s_email) {
        this.s_email = s_email;
    }

    public String getS_address() {
        return s_address;
    }

    public void setS_address(String s_address) {
        this.s_address = s_address;
    }

    public String getSc_name() {
        return sc_name;
    }

    public void setSc_name(String sc_name) {
        this.sc_name = sc_name;
    }

    public String getSa_number() {
        return sa_number;
    }

    public void setSa_number(String sa_number) {
        this.sa_number = sa_number;
    }
    
}
