
package p1;

import javax.persistence.*;
@Entity
public class MnagaeRoom {
    @Id
    private int room_no;

    public int getRoom_no() {
        return room_no;
    }

    public void setRoom_no(int room_no) {
        this.room_no = room_no;
    }

    public String getR_booked() {
        return r_booked;
    }

    public void setR_booked(String r_booked) {
        this.r_booked = r_booked;
    }
    private String r_booked;
    
}
